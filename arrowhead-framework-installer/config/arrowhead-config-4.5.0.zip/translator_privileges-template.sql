USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'translator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'translator'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'translator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'translator'@'%';

FLUSH PRIVILEGES;