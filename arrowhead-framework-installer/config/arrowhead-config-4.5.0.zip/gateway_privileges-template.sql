USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'gateway'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'gateway'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'gateway'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'gateway'@'%';

FLUSH PRIVILEGES;
