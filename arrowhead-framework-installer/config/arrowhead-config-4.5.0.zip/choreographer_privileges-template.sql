USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_plan` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_step` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_step_service_definition_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_step_next_step_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_session` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_running_step` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_worklog` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_plan` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_step` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_step_service_definition_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_step_next_step_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_session` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_running_step` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_worklog` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';

FLUSH PRIVILEGES;