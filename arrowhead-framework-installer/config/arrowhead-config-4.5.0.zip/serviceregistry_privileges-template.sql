USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'service_registry'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry_interface_connection` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`relay` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gatekeeper_relay` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gateway_relay` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud_interface_connection` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`orchestrator_store` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription_publisher_connection` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_plan` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_step` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_plan_action_connection` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_action_step_connection` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_step_service_definition_connection` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_next_action_step` TO 'service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'service_registry'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'service_registry'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry_interface_connection` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`relay` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gatekeeper_relay` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gateway_relay` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud_interface_connection` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`orchestrator_store` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription_publisher_connection` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_plan` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_step` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_plan_action_connection` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_action_step_connection` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_step_service_definition_connection` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_next_action_step` TO 'service_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'service_registry'@'%';

FLUSH PRIVILEGES;