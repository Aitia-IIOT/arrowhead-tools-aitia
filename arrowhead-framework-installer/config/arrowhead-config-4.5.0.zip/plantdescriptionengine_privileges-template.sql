USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'plant_description_engine'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`pde_rule` TO 'plant_description_engine'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`plant_description` TO 'plant_description_engine'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'plant_description_engine'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'plant_description_engine'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`pde_rule` TO 'plant_description_engine'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`plant_description` TO 'plant_description_engine'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'plant_description_engine'@'%';

FLUSH PRIVILEGES;
