USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'orchestrator'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`orchestrator_store` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`foreign_system` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`orchestrator_store_flexible` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`relay` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gatekeeper_relay` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gateway_relay` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_reservation` TO 'orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'orchestrator'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'orchestrator'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`orchestrator_store` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`foreign_system` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`orchestrator_store_flexible` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`relay` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gatekeeper_relay` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gateway_relay` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_reservation` TO 'orchestrator'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'orchestrator'@'%';

FLUSH PRIVILEGES;