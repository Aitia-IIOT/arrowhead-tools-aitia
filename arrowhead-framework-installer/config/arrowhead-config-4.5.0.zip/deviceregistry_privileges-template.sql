USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'device_registry'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`device` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`device_registry` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry_interface_connection` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud_interface_connection` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO 'device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'device_registry'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'device_registry'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`device` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`device_registry` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry_interface_connection` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud_interface_connection` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO 'device_registry'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'device_registry'@'%';

FLUSH PRIVILEGES;