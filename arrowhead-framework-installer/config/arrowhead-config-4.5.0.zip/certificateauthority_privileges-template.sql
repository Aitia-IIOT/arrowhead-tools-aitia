USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`ca_certificate` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`ca_trusted_key` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`ca_certificate` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`ca_trusted_key` TO '{db.user}'@'%';

FLUSH PRIVILEGES;
