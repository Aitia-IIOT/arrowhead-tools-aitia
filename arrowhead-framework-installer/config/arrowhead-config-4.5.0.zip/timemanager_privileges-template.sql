USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'timemanager'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'timemanager'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'timemanager'@'%';

FLUSH PRIVILEGES;
