USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'datamanager'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`dmhist_services` TO 'datamanager'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`dmhist_files` TO 'datamanager'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`dmhist_messages` TO 'datamanager'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`dmhist_entries` TO 'datamanager'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'datamanager'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'datamanager'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`dmhist_services` TO 'datamanager'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`dmhist_files` TO 'datamanager'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`dmhist_messages` TO 'datamanager'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`dmhist_entries` TO 'datamanager'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'datamanager'@'%';

FLUSH PRIVILEGES;
