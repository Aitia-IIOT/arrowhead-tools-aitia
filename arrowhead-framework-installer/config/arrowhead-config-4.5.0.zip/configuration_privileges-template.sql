USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'configuration'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`configuration_data` TO 'configuration'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'configuration'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`configuration_data` TO 'configuration'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'configuration'@'%';

FLUSH PRIVILEGES;
