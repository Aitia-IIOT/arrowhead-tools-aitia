USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'event_handler'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`event_type` TO 'event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription` TO 'event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription_publisher_connection` TO 'event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO 'event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'event_handler'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'event_handler'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`event_type` TO 'event_handler'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription` TO 'event_handler'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription_publisher_connection` TO 'event_handler'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO 'event_handler'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'event_handler'@'%';

FLUSH PRIVILEGES;