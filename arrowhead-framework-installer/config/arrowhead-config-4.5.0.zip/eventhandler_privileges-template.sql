USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`event_type` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription_publisher_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`event_type` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription_publisher_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';

FLUSH PRIVILEGES;