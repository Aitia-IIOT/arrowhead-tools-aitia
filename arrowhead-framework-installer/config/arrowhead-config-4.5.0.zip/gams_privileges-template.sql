USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_action` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_action_plan` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_processable_action` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_composite_action` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_composite_action_actions` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_event_action` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_logging_action` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_action_plan_actions` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_event` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_http_body_api_call` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_http_url_api_call` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_instance` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor_data` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor_data_double` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor_data_long` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor_data_string` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_aggregation` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_counting_aggregation` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_timeout_guard` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_analysis` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_setpoint_analysis` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_counting_analysis` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_timeout_guard` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_policy` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_match_policy` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_transform_policy` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_api_policy` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';


GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_action` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_action_plan` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_processable_action` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_composite_action` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_composite_action_actions` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_event_action` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_event_action` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_action_plan_actions` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_event` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_http_body_api_call` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_http_url_api_call` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_instance` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor_data` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor_data_double` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor_data_long` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_sensor_data_string` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_aggregation` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_counting_aggregation` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_timeout_guard` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_analysis` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_setpoint_analysis` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_counting_analysis` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_timeout_guard` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_policy` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_match_policy` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_transform_policy` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`gams_api_policy` TO '{db.user}'@'%';

FLUSH PRIVILEGES;