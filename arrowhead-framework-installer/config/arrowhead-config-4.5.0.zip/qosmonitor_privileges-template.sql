USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement_log` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement_log_details` TO 'qos_monitor'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement_log` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement_log_details` TO 'qos_monitor'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_echo_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_echo_measurement_log` TO 'qos_monitor'@'localhost';

GRANT SELECT ON `{db.name}`.`system_` TO 'qos_monitor'@'localhost';
GRANT SELECT ON `{db.name}`.`cloud` TO 'qos_monitor'@'localhost';
GRANT SELECT ON `{db.name}`.`relay` TO 'qos_monitor'@'localhost';
GRANT SELECT ON `{db.name}`.`cloud_gatekeeper_relay` TO 'qos_monitor'@'localhost';
GRANT SELECT ON `{db.name}`.`cloud_gateway_relay` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'qos_monitor'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement_log` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement_log_details` TO 'qos_monitor'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement_log` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement_log_details` TO 'qos_monitor'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_echo_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_echo_measurement_log` TO 'qos_monitor'@'%';

GRANT SELECT ON `{db.name}`.`system_` TO 'qos_monitor'@'%';
GRANT SELECT ON `{db.name}`.`cloud` TO 'qos_monitor'@'%';
GRANT SELECT ON `{db.name}`.`relay` TO 'qos_monitor'@'%';
GRANT SELECT ON `{db.name}`.`cloud_gatekeeper_relay` TO 'qos_monitor'@'%';
GRANT SELECT ON `{db.name}`.`cloud_gateway_relay` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO 'qos_monitor'@'%';

FLUSH PRIVILEGES;