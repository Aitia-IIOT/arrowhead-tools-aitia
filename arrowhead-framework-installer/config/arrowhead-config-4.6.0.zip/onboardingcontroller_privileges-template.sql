USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';

FLUSH PRIVILEGES;