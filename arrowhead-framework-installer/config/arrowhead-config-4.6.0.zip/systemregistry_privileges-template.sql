USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`device` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_registry` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry_interface_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud_interface_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`device` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_registry` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry_interface_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud_interface_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';

FLUSH PRIVILEGES;