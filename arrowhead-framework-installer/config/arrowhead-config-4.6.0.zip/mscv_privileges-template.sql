USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_target` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_ssh_target` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip_category` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip_domain` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_standard` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip_verification_list` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip_verification_entry` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_script` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_verification_result` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_verification_result_detail` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_JOB_DETAILS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_TRIGGERS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_SIMPLE_TRIGGERS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_CRON_TRIGGERS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_SIMPROP_TRIGGERS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_BLOB_TRIGGERS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_CALENDARS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_PAUSED_TRIGGER_GRPS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_FIRED_TRIGGERS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_SCHEDULER_STATE` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_LOCKS` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_target` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_ssh_target` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip_category` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip_domain` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_standard` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip_verification_list` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_mip_verification_entry` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_script` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_verification_result` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`mscv_verification_result_detail` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_JOB_DETAILS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_TRIGGERS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_SIMPLE_TRIGGERS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_CRON_TRIGGERS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_SIMPROP_TRIGGERS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_BLOB_TRIGGERS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_CALENDARS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_PAUSED_TRIGGER_GRPS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_FIRED_TRIGGERS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_SCHEDULER_STATE` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`MSCV_QRTZ_LOCKS` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';

FLUSH PRIVILEGES;