USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry_interface_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`relay` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gatekeeper_relay` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gateway_relay` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud_interface_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`orchestrator_store` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription_publisher_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_plan` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_step` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_plan_action_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_action_step_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_step_service_definition_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_next_action_step` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_registry_interface_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`relay` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gatekeeper_relay` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gateway_relay` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_intra_cloud_interface_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`orchestrator_store` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`subscription_publisher_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_plan` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_step` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_plan_action_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_action_step_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_action_step_service_definition_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`choreographer_next_action_step` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';

FLUSH PRIVILEGES;