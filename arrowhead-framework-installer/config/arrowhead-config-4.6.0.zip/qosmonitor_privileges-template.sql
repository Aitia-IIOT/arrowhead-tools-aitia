USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_measurement` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement_log` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement_log_details` TO '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_measurement` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement_log` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement_log_details` TO '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_measurement` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_echo_measurement` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_echo_measurement_log` TO '{db.user}'@'localhost';

GRANT SELECT ON `{db.name}`.`system_` TO '{db.user}'@'localhost';
GRANT SELECT ON `{db.name}`.`cloud` TO '{db.user}'@'localhost';
GRANT SELECT ON `{db.name}`.`relay` TO '{db.user}'@'localhost';
GRANT SELECT ON `{db.name}`.`cloud_gatekeeper_relay` TO '{db.user}'@'localhost';
GRANT SELECT ON `{db.name}`.`cloud_gateway_relay` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_measurement` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement_log` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_intra_ping_measurement_log_details` TO '{db.user}'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_measurement` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement_log` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_direct_ping_measurement_log_details` TO '{db.user}'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_measurement` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_echo_measurement` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`qos_inter_relay_echo_measurement_log` TO '{db.user}'@'%';

GRANT SELECT ON `{db.name}`.`system_` TO '{db.user}'@'%';
GRANT SELECT ON `{db.name}`.`cloud` TO '{db.user}'@'%';
GRANT SELECT ON `{db.name}`.`relay` TO '{db.user}'@'%';
GRANT SELECT ON `{db.name}`.`cloud_gatekeeper_relay` TO '{db.user}'@'%';
GRANT SELECT ON `{db.name}`.`cloud_gateway_relay` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';

FLUSH PRIVILEGES;