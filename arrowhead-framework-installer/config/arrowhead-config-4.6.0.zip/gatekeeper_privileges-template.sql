USE `{db.name}`;

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'localhost';

GRANT ALL PRIVILEGES ON `{db.name}`.`cloud` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`relay` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gatekeeper_relay` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gateway_relay` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`foreign_system` TO '{db.user}'@'localhost';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'localhost';

REVOKE ALL, GRANT OPTION FROM '{db.user}'@'%';

GRANT ALL PRIVILEGES ON `{db.name}`.`cloud` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`relay` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`system_` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_definition` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`service_interface` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gatekeeper_relay` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`cloud_gateway_relay` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`authorization_inter_cloud_interface_connection` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`foreign_system` TO '{db.user}'@'%';
GRANT ALL PRIVILEGES ON `{db.name}`.`logs` TO '{db.user}'@'%';

FLUSH PRIVILEGES;